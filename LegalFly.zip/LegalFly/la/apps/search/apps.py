from django.apps import AppConfig


class SearchConfig(AppConfig):
    """Config app search"""

    name = 'apps.search'

    def ready(self):
        pass
