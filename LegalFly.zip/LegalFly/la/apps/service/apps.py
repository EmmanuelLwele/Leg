from django.apps import AppConfig


class ServiceConfig(AppConfig):
    """Config app service"""

    name = 'apps.service'
