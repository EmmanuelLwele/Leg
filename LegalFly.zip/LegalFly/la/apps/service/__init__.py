"""The application works with services"""
