"""The application works with users"""
