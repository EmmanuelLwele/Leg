"""The application works with billing"""
