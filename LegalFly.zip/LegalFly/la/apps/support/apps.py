from django.apps import AppConfig


class SupportConfig(AppConfig):
    """Config app support"""

    name = 'apps.support'
